Python 3.12.3 (tags/v3.12.3:f6650f9, Apr  9 2024, 14:05:25) [MSC v.1938 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
============================================================ RESTART: C:/Users/91630/OneDrive/Desktop/New folder/project.py ============================================================
5
enter a over1
1 2 3 w 4 6
16 1
enter a over2
2 3 3 6 3 3
36 1
enter a over3
2 6 4 w 3 2 
53 2
enter a over4
1 2 3 4 6 3
72 2
enter a over5
w 3 2 4 1 w
82 4
total score: 82 for 4 wicktes
{'virat': 2, 'rohith': 30, 'rakesh': 30, 'vamsi': 14, 'dhoni': 6, 'jaddu': 0, 'hardik': 0, 'gail': 0, 'dube': 0, 'bumra': 0, 'shami': 0}
